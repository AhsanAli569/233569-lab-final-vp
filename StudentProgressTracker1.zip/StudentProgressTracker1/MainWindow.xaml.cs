﻿using System;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace StudentProgressTracker
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Student> Students { get; set; }
        private StudentManager _studentManager;

        public MainWindow()
        {
            InitializeComponent();
            _studentManager = new StudentManager();
            Students = new ObservableCollection<Student>(_studentManager.LoadStudents());
            DataContext = this;
        }

        private void ComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            // Fetch the selected grade and subject values from the combo boxes
            string selectedGrade = GradeComboBox.SelectedItem is ComboBoxItem gradeItem ? gradeItem.Content.ToString() : null;
            string selectedSubject = SubjectComboBox.SelectedItem is ComboBoxItem subjectItem ? subjectItem.Content.ToString() : null;

            // Filtering logic based on selected values
            var filteredStudents = _studentManager.FilterStudents(selectedGrade, selectedSubject);

            // Clear the existing collection and add the filtered results
            Students.Clear();
            foreach (var student in filteredStudents)
            {
                Students.Add(student);
            }
        }

        private void AddStudentButton_Click(object sender, RoutedEventArgs e)
        {
            var newStudent = new Student { Name = "New Student", Grade = "B", Subject = "Math", Marks = 80, Attendance = 90 };
            _studentManager.AddStudent(newStudent);
            Students.Add(newStudent);
            MessageBox.Show("Student added successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void EditStudentButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedStudent = (Student)StudentsDataGrid.SelectedItem;
            if (selectedStudent != null)
            {
                // We don't need to manually modify the properties here. Just call the Save method
                _studentManager.UpdateStudent(selectedStudent);

                // Refresh the grid after making changes
                StudentsDataGrid.Items.Refresh();
                MessageBox.Show("Student updated successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("No student selected.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void DeleteStudentButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedStudent = (Student)StudentsDataGrid.SelectedItem;
            if (selectedStudent != null)
            {
                _studentManager.DeleteStudent(selectedStudent.StudentId);
                Students.Remove(selectedStudent);
                MessageBox.Show("Student deleted successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("No student selected.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

    public class Student
    {
        public int StudentId { get; set; }
        public string Name { get; set; }
        public string Grade { get; set; }
        public string Subject { get; set; }
        public int Marks { get; set; }
        public decimal Attendance { get; set; }
    }

    public class StudentManager
    {
        private readonly string _connectionString = "Server=DESKTOP-UOE9NMU\\SQLEXPRESS;Database=StudentProgressTracker;Integrated Security=True;";

        public ObservableCollection<Student> LoadStudents()
        {
            var students = new ObservableCollection<Student>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("SELECT * FROM Students", connection);
                var reader = command.ExecuteReader();

                while (reader.Read())
                {
                    var student = new Student
                    {
                        StudentId = (int)reader["StudentId"],
                        Name = reader["Name"].ToString(),
                        Grade = reader["Grade"].ToString(),
                        Subject = reader["Subject"].ToString(),
                        Marks = (int)reader["Marks"],
                        Attendance = (decimal)reader["Attendance"]
                    };
                    students.Add(student);
                }
            }
            return students;
        }

        public void AddStudent(Student student)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("INSERT INTO Students (Name, Grade, Subject, Marks, Attendance) VALUES (@Name, @Grade, @Subject, @Marks, @Attendance)", connection);
                command.Parameters.AddWithValue("@Name", student.Name);
                command.Parameters.AddWithValue("@Grade", student.Grade);
                command.Parameters.AddWithValue("@Subject", student.Subject);
                command.Parameters.AddWithValue("@Marks", student.Marks);
                command.Parameters.AddWithValue("@Attendance", student.Attendance);
                command.ExecuteNonQuery();
            }
        }

        public void UpdateStudent(Student student)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("UPDATE Students SET Name = @Name, Grade = @Grade, Subject = @Subject, Marks = @Marks, Attendance = @Attendance WHERE StudentId = @StudentId", connection);

                command.Parameters.AddWithValue("@Name", student.Name);
                command.Parameters.AddWithValue("@Grade", student.Grade);
                command.Parameters.AddWithValue("@Subject", student.Subject);
                command.Parameters.AddWithValue("@Marks", student.Marks);
                command.Parameters.AddWithValue("@Attendance", student.Attendance);
                command.Parameters.AddWithValue("@StudentId", student.StudentId);

                // Execute the update query
                command.ExecuteNonQuery();
            }
        }


        public void DeleteStudent(int studentId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("DELETE FROM Students WHERE StudentId = @StudentId", connection);
                command.Parameters.AddWithValue("@StudentId", studentId);
                command.ExecuteNonQuery();
            }
        }

        public ObservableCollection<Student> FilterStudents(string grade, string subject)
        {
            var students = new ObservableCollection<Student>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT * FROM Students WHERE (Grade LIKE @Grade) AND (Subject LIKE @Subject)";
                var command = new SqlCommand(query, connection);

                // Use "%" for optional matching
                command.Parameters.AddWithValue("@Grade", string.IsNullOrEmpty(grade) ? "%" : grade);
                command.Parameters.AddWithValue("@Subject", string.IsNullOrEmpty(subject) ? "%" : subject);

                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var student = new Student
                    {
                        StudentId = (int)reader["StudentId"],
                        Name = reader["Name"].ToString(),
                        Grade = reader["Grade"].ToString(),
                        Subject = reader["Subject"].ToString(),
                        Marks = (int)reader["Marks"],
                        Attendance = (decimal)reader["Attendance"]
                    };
                    students.Add(student);
                }
            }
            return students;
        }
    }
}
